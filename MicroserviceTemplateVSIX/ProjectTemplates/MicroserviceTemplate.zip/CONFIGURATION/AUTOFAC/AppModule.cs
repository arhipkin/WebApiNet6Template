﻿using Autofac;
using $safeprojectname$.Controllers;
using Microsoft.Extensions.Options;

namespace $safeprojectname$.Configuration.Autofac
{
    public class AppModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            //builder.RegisterGeneric(typeof(ConfigureAppOptions<>)).As(typeof(IConfigureOptions<>)).SingleInstance();
            //builder.RegisterType<TestService>().As<ITestService>().InstancePerRequest();
        }
    }
}
