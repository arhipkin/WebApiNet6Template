﻿using $safeprojectname$.Settings;

namespace $safeprojectname$.Configuration
{
    public static class ApplicationSettings
    {
        public static void AddSettings(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<WeatherForecast>(configuration.GetSection(nameof(WeatherForecast)));
        }
    }
}
