﻿using AutoMapper;

namespace $safeprojectname$.Configuration.AutoMapperProfiles
{
    public class DefaultProfile : Profile
    {
        public DefaultProfile()
        {

        }
    }
}
